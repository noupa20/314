package com.clients.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.clients.dao.ClientDao;
import com.clients.model.Client;

/**
 * Servlet implementation class ClientServlet
 */
@WebServlet("/ClientServlet")
public class ClientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ClientDao clientdao;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClientServlet() {
        super();
        // TODO Auto-generated constructor stub
        clientdao = new ClientDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		this.getServletContext().getRequestDispatcher(" ").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		  
	    	String Name = request.getParameter("Name");
	        String Prenom = request.getParameter("Prenom");
	        String Adresse = request.getParameter("Adresse");
	        String Numero = request.getParameter("Numero");
	        String Email = request.getParameter("Email");
	        String Date = request.getParameter("Date");
	        String Montant = request.getParameter("Montant");

	        Client client = new Client();
	        client.setName(Name);
	        client.setPrenom(Prenom);
	        client.setAdresse(Adresse);
	        client.setNumero(Numero);
	        client.setEmail(Email);
	        client.setDate(Date);
	        client.setMontant(Montant);

	        try {
	            clientdao.clientDonn�es(client);
	        } catch (Exception e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }

	        response.sendRedirect("index.html");
	}

}
