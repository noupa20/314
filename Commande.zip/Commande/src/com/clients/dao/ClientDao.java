package com.clients.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.clients.model.Client;



public class ClientDao {

	
	public int clientDonn�es(Client client)  throws ClassNotFoundException {
        String INSERT_USERS_SQL = "INSERT INTO client" +
                "  (Name, Prenom, Adresse, Numero, Email, date, Montant) VALUES " +
                " (?, ?, ?, ?, ?,?,?);";

            int result = 0;

            Class.forName(" ");

            
            try (Connection connection = DriverManager
                    .getConnection(" ", "root", "root");

                    // Step 2:Create a statement using connection object
                    PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
                    preparedStatement.setInt(1, 1);
                    preparedStatement.setString(2, client.getName());
                    preparedStatement.setString(3, client.getPrenom());
                    preparedStatement.setString(4, client.getAdresse());
                    preparedStatement.setString(5, client.getNumero());
                    preparedStatement.setString(6, client.getEmail());
                    preparedStatement.setString(7, client.getDate());
                    preparedStatement.setString(7, client.getMontant());

                    System.out.println(preparedStatement);
                   
                    result = preparedStatement.executeUpdate();

                } catch (SQLException e) {
                    //  sql exception process
                    printSQLException(e);
                }
                return result;
            }

            private void printSQLException(SQLException ex) {
                for (Throwable e: ex) {
                    if (e instanceof SQLException) {
                        e.printStackTrace(System.err);
                        System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                        System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                        System.err.println("Message: " + e.getMessage());
                        Throwable t = ex.getCause();
                        while (t != null) {
                            System.out.println("Cause: " + t);
                            t = t.getCause();
                        }
                    }
                }
            }
}
